﻿using System;

class Program
{
    static void Main(string[] args)
    {

        // Welcome message
        Console.WriteLine("Bienvenido, ¿desea entrar a la aplicación?(yes/no)");
        string respuesta = Console.ReadLine().ToLower();

        // Loop until the user decides put "no"
        while (respuesta != "no")
        {

            // Ask for the user's name and age
            Console.WriteLine("\nPerfecto!! Introduce tu nombre: ");
            string nombre = Console.ReadLine();

            Console.WriteLine($"\nGenial {nombre}, introduce tu edad por favor");
            int edad = Int32.Parse(Console.ReadLine());

            // If the user is 18 or older, show available positions
            if (edad >= 18)
            {

                // Ask for the user's position
                Console.WriteLine($"\nPerfecto {nombre}, actualmente tenemos estos cargos disponibles: ");
                Console.WriteLine("\nSi tu cargo está entre los siguientes elige tu cargo: ");

                // List of available positions
                Console.WriteLine("\n 1. Gerente \n 2. Desarrollador \n 3. Analista \n 4. Asistente \n 5. Becario");
                int respuestaCargo = Int32.Parse(Console.ReadLine());

                // Switch case to determine the salary based on the selected position
                switch (respuestaCargo)
                {

                    case 1:
                        Console.WriteLine($"\nPerfecto {nombre}, como gerente tendrás un sueldo de 2000 euros brutos al mes");
                        break;

                    case 2:
                        Console.WriteLine($"\nPerfecto {nombre}, como desarrollador tendrás un sueldo de 2200 euros brutos al mes");
                        break;

                    case 3:
                        Console.WriteLine($"\nPerfecto {nombre}, como analista tendrás un sueldo de 1800 euros brutos al mes");
                        break;

                    case 4:
                        Console.WriteLine($"\nPerfecto {nombre}, como asistente tendrás un sueldo de 1500 euros brutos al mes");
                        break;

                    case 5:
                        Console.WriteLine($"\nPerfecto {nombre}, como becario tendrás un sueldo de 300 euros brutos al mes");
                        break;

                    default:
                        Console.WriteLine($"\nOpción no válida");
                        break;

                }

            }
            else
            {
                // If the user is under 18, show a message
                Console.WriteLine($"\nLo siento {nombre}, pero necesitas ser mayor de edad");
            }

            // Ask if the user wants to continue
            Console.WriteLine("\n¿Desea continuar en la aplicación? (yes/no)");
            respuesta = Console.ReadLine().ToLower();
        }

        // Exit message
        Console.WriteLine("\nGracias por usar la aplicación");
    }
}
