﻿using System;

class Program
{
    static void Main(string[] args)
    {

        // Welcome to the cash register
        Console.WriteLine("********** Bienvenido a la caja registradora **********");

        // Prompt for user input, asking for product details
        Console.WriteLine("\nIngrese el nombre del producto: ");
        string nombreProducto = Console.ReadLine();

        // Prompt for user input, asking for product price
        Console.WriteLine("\nIngrese el precio del producto: ");
        double precioProducto = double.Parse(Console.ReadLine());

        // Prompt for user input, asking for product quantity
        Console.WriteLine("\nIngrese la cantidad de productos: ");
        int cantidadProducto = Int32.Parse(Console.ReadLine());

        // Calculate the total price and apply discount if applicable
        double precioFinal = precioProducto * cantidadProducto;
        Console.WriteLine($"\nTotal a pagar: {precioFinal}");

        // Check if the total price is greater than 100 to apply a discount
        if (precioFinal > 100)
        {
            // Apply a 10% discount
            Console.WriteLine("\nEl precio es mayor a 100, se aplica un descuento del 10%");
            double descuento = precioFinal * 0.10;
            precioFinal -= descuento;
            Console.WriteLine($"\nTotal a pagar con descuento: {precioFinal}");
        }
        else
        {
            // No discount applied
            Console.WriteLine("\nEl precio es menor o igual a 100, no se aplica descuento");

        }
    }
}