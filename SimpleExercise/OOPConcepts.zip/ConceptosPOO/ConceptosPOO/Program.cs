﻿using System;

namespace ConceptosPOO
{
    class Program
    {
        static void Main(string[] args)
        {
            // Call to the realizarTarea method
            realizarTarea();
        }

        static void realizarTarea()
        {
            // Create an object of the Punto class
            Punto origen = new Punto();

            // Create another object of the Punto class
            Punto destino = new Punto(150, 90);

            double distancia = origen.DistanciaHasta(destino);

            Console.WriteLine($"The distance between the points is: {distancia}");
        }
    }
}
