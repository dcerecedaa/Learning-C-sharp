﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConceptosPOO
{
    class Punto
    {
        // Class fields
        private int x, y;

        public Punto(int x, int y)
        {
            // Constructor with parameters
            this.x = x; // Class field x will be equal to the value passed as parameter x
            this.y = y; // Class field y will be equal to the value passed as parameter y
        }

        public Punto()
        {
            // Default constructor
            this.x = 0; // Class field x will be set to 0
            this.y = 0; // Class field y will be set to 0
        }

        public double DistanciaHasta(Punto otroPunto)
        {
            // Calculate the difference in X between the current point and the other point
            int xDif = this.x - otroPunto.x;

            // Calculate the difference in Y between the current point and the other point
            int yDif = this.y - otroPunto.y;

            // Calculate the Euclidean distance between the two points using the Pythagorean theorem
            double distanciaPuntos = Math.Sqrt(Math.Pow(xDif, 2) + Math.Pow(yDif, 2));

            // Return the distance between the two points
            return distanciaPuntos;
        }
    }
}
